# Notes+

A simple dynamic website for notes aggregation by students

Made by using - PHP, MySQL, CSS(Bootstrap, Font-Awesome Icons), Javascript(jQuery)
